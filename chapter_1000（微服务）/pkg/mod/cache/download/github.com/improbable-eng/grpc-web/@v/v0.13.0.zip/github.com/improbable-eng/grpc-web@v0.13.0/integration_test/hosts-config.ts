// These must match the hosts configured in .travis.yml
export const testHost = "testhost";
export const corsHost = "corshost";
