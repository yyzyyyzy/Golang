import "./client.spec";
import "./client.websocket.spec";
import "./invoke.spec";
import "./unary.spec";
import "./cancellation.spec";
import "./ChunkParser.spec";

jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
